package com.example.twoj_bagaz;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.twoj_bagaz.R;

public class KosmetykiActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kosmetyki);
    }
}
