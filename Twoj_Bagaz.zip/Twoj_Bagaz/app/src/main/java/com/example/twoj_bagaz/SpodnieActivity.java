package com.example.twoj_bagaz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.twoj_bagaz.R;

public class SpodnieActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spodnie);
    }
}
